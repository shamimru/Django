/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package class_13_1_23;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

/**
 *
 * @author IDB-CF
 */
public class Class_13_1_23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        File f=new File("txt.txt");
        try{
           FileReader fr=new FileReader(f);

           char [] c=new char[256];
           int i=0;
           i=fr.read();
           while(i != -1){
               System.out.println(c);
               i=fr.read();
           }
           
        }catch(Exception e){
            System.out.println(e);
        }
        
        
        
        // TODO code application logic here
//        Scanner sc=new Scanner(System.in);
//        File f=new File("txt.txt");
//        try{
////             FileOutputStream fi= new FileOutputStream(f);
//
//             FileWriter fw=new FileWriter(f,true);
////             ObjectOutputStream oout=new  ObjectOutputStream(fi);
//             
//             System.out.println("Enter your data");
//                     
////            String name=sc.nextLine();
//            
//            
//            
////            fw.write(name);
////             fw.write("Hello shamim");
//             fw.flush();
//             fw.close();
//             System.out.println("File Reading");
//        }catch(Exception e){
//            System.out.println(e);
//                
//            }
//        
//        try{
//            FileReader fr=new FileReader("txt.txt");
//            BufferedReader br=new BufferedReader(fr);
//            while (br.ready()){
//               br.readLine();
//            }
//            
//        }catch(Exception e){
//            System.out.println(e);
//        }
//            
//        
//       
//        
//        String delimiter = System.getProperty("line.separator");
//        System.out.println(delimiter);
////      int j;
////      for(j=1;j<6;j++){
////          if(j > 3)
////              continue;
////          
////          System.out.println(j);
////      }
////      System.out.println(j);
////        
////        
////        System.out.println(factorial(1));
////        
////        
////        String name="shamim";
////        
////        System.out.println(name.replace('m', 'T'));
////        if(1+1+1 == 3){
////            System.out.println("true");
////        }else{
////            System.out.println("false");
////        }
////        
//        
//        
    }
    
    public static long factorial( int n){
        
        if(n== 0){
            return 1;
        }
        return n * factorial(n - 1);
    }
    
}
