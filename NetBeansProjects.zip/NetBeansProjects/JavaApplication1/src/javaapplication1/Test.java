/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author IDB-CF
 */
public class Test {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("File writter");

        try {
            String st = "D:\\shamim";

            String f2 = st + "\\text.txt";
            File f = new File(st);
//            f.createNewFile();
            f.createNewFile();

            PrintWriter pw = new PrintWriter(f);

            System.out.println("Enter your name");

            String name = sc.nextLine();
            pw.println(name);
//            pw.print("hello ");
//            pw.print("my name is shamim");
//            pw.print(" ahamed ");

            pw.flush();
            pw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
