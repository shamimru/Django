/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.account;

/**
 *
 * @author IDB-CF
 */
public class Exam {
    
    public static void main(String [] args){
       int [] A={0,2,4,1,3};
       int i=0;
       for( i=0;i<A.length;i++){
           A[i] = A[(A[i] + 3) % A.length];
//            System.out.println(A[i]); 

       }
//        System.out.println(A[1]); 
//        
        System.out.println(3%5);
               
        
                
    }
    
}
