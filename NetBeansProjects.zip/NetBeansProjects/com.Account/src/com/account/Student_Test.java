/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.account;

/**
 *
 * @author IDB-CF
 */
public class Student_Test {
    
    public static void main(String [] args){
        
        Person person=new Person("shamim");
        
        Student student_1=new Student(101,"abc@gmail.com",57,"kushtia");
        Student student_2=new Student(102,"abcd@gmail.com",56,"rajshahi");
        Student student_3=new Student(103,"abcde@gmail.com",54,"Khulna");
        
    }
    
}
