/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.account;

/**
 *
 * @author IDB-CF
 */
public class Student extends Person {
    int id;
    String email;
    int round;
    String address;
        
    Student(){
        super();
    }
    Student(String name,int id,String email,int round,String address){
        super();
        this.name=name;
        this.id=id;
        this.email=email;
        this.round=round;
        this.address=address;
    }
        
    public void show(){
        System.out.print("---------------------------------------");
        
        System.out.println("Your Name is -> "+name +"Your id is -> "+id +" and Email is -> "+ id+" and Round is -> "+round + " and Your Address is -> "+address);
        System.out.print("---------------------------------------");

        
    }
  
    
}
