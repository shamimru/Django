/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package class_16_1_24;

import java.io.Serializable;

/**
 *
 * @author IDB-CF
 */
public class Object_input_Stream  implements Serializable{
    int id;
    String name;

    public Object_input_Stream() {
    }

    public Object_input_Stream(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Object_input_Stream{" + "id=" + id + ", name=" + name + '}';
    }
    
    
    
}
