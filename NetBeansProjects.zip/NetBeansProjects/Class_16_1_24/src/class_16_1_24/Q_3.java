/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package class_16_1_24;

/**
 *
 * @author IDB-CF
 */
public class Q_3 {
    public static void main(String... args){
        
        int [] arr={2,4};
        String o=null;
        try{
            System.out.println(10/0);
            System.out.println(arr[3]);
            System.out.println(o.length());
            
        }catch(ArithmeticException  e){
            System.out.println("can not divided by Zero -> "+e);
        }catch(ArrayIndexOutOfBoundsException e){
        System.out.println("Array is out of Bounds");
        }catch(NullPointerException e){
            System.out.println("No such type of object present "+e);
        }
    }
    
}
