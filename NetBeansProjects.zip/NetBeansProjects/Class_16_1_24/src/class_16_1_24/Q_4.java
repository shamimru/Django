/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package class_16_1_24;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author IDB-CF
 */
public class Q_4 {
    
    public static void main(String... args){
        File f=new File("object.txt");
        try{
            FileOutputStream fs=new FileOutputStream(f);
            ObjectOutputStream os=new ObjectOutputStream(fs);
            
            Object_input_Stream obj1=new Object_input_Stream(101,"shamim");
            Object_input_Stream obj2=new Object_input_Stream(102,"Ahamed");
                    
            os.writeObject(obj1);
            os.writeObject(obj2);
            
            os.flush();
            os.close();
            
            
            FileInputStream fi=new FileInputStream(f);
            ObjectInputStream oos= new ObjectInputStream(fi);
            
           Object_input_Stream obj3=(Object_input_Stream) oos.readObject();
           Object_input_Stream obj4=(Object_input_Stream) oos.readObject();
           
            System.out.println("Id is -> "+obj3.id +" and Name is -> "+obj3.name);
            System.out.println("Id is -> "+obj4.id +" and Name is -> "+obj4.name);
//            System.out.println(obj4);
            oos.close();
            
                    

        }catch(Exception e){
            System.out.println(e);
        }
    }
    
}
