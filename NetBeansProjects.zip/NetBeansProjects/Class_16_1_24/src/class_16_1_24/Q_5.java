/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package class_16_1_24;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 *
 * @author IDB-CF
 */
public class Q_5{
    
    public static void main(String... args){
          File f=new File("text.txt");
        try{
          FileWriter fs =new FileWriter(f);
           PrintWriter pw=new PrintWriter(fs);
           
           pw.write("Hello ");
           pw.write(" Bangladesh ");
           pw.write("jaman ");
           
           pw.flush();
           pw.close();
          
               FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);

            String read;
            while ((read = br.readLine()) != null) {
                System.out.print(read);
                System.out.println();
            }

            fr.close();
            
           
        }catch(Exception e){
            System.out.println(e);
        }
        
//        try{
//            
//            
//            
//        }catch(Exception e){
//            System.out.println(e);
//        }
       
    }
    
}
