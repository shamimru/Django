/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author IDB-CF
 */
public class Student extends Person{
    int id;
    String email;
    int round;
    String address;

    public Student() {
    }

    public Student(String name,int id, String email, int round, String address) {
        super(name);
        this.id = id;
        this.email = email;
        this.round = round;
        this.address = address;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", email=" + email + ", round=" + round + ", address=" + address + '}';
    }

   public String showAddress(){
       return this.address;
   }
    
    
}
