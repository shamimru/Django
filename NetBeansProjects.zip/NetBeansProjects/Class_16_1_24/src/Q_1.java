
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author IDB-CF
 */
public class Q_1 {
    
    public static void main (String... args){
        
        
        Student st1=new Student("ali",101,"abc@gmail.com",56,"Kushtia");
        Student st2=new Student("Hyder",102,"def@gmail.com",57,"Khulna");
        
        ArrayList <Student> lists=new ArrayList<>();
        lists.add(st1);
        lists.add(st2);
        
        for(Student list:lists){
            System.out.println("Your id is -> "+list.id+ " email -> "+list.email+" round -> "+ list.round+" Address is -> "+list.address);
        }
//        System.out.println(st1.showAddress()); 
//        System.out.println(st2.showAddress()); 
    }
    
}
