/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Q_2;

/**
 *
 * @author IDB-CF
 */
public class Account extends Bank{
    int accNo;
    String accName;
    double balance;

    public Account() {
    }

    public Account(int accNo, String accName, double balance) {
        this.accNo = accNo;
        this.accName = accName;
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Account{" + "accNo=" + accNo + ", accName=" + accName + ", balance=" + balance + '}';
    }
    
    
    @Override
    public double deposit(double amt){
        this.balance=this.balance+amt;
        return this.balance;
    }
    
    @Override
    public double withwraw(double amt){
        this.balance=this.balance - amt;
        return this.balance;
    }
    
}
