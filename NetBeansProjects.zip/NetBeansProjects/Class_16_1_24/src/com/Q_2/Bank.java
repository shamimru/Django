/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Q_2;

/**
 *
 * @author IDB-CF
 */
public class Bank {
    public double withwraw(double amt){
        return amt;
    }
     public double deposit(double amt){
        return amt;
    }
    
}
