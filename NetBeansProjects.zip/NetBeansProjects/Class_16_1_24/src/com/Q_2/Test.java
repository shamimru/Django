/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Q_2;

import java.util.ArrayList;

/**
 *
 * @author IDB-CF
 */
public class Test {
    public static void main(String... args){
        //accNo;
       // this.accName = accName;
        //this.balance = balance;
        Account ac1=new Account(10001,"shamim",40000);
        Account ac2=new Account(10005,"Jaman",50000);
        
        ArrayList <Account> lists=new ArrayList<>();
        
        lists.add(ac1);
        lists.add(ac2);
        
        for(Account ac:lists){
            System.out.println("Account No is -> "+ac.accNo+ " Account Name "+ac.accName+" Balance = "+ac.balance);
        }
    }
    
}
